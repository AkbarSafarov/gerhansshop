document.addEventListener("DOMContentLoaded", function() {

    const body = document.body;
    const html = document.documentElement;
    const overflowHidden = 'oveflowHidden';
    const menuBurger = document.querySelector('.menu_burger');
    const discountBanner = document.querySelector('.discount_banner');
    const header = document.querySelector('.header');
    const slider = document.querySelector('.slider_top_block');
    const menuHeader = document.querySelector('.menu-header');
    const tmenuOffset = header.offsetTop;

    let lastScrollY = window.scrollY; 
    let isScrollingUp = false; 

    const menuItems = document.querySelectorAll('.menu_header .name li');
    const images = document.querySelectorAll('.menu_header .img li');
    
    if(menuItems.length) {
        menuItems.forEach((item, index) => {
            item.addEventListener('mouseenter', function() {
                images.forEach(img => {
                    img.style.display = 'none';
                });
                
                if (images[index]) {
                    images[index].style.display = 'list-item';
                }
            });
        });
    }

    const sliderMain = document.querySelector('.slider_main');

    if(sliderMain){
        const menuSwiper = new Swiper('.menu-swiper', {
            direction: 'vertical',
            slidesPerView: 4,
            spaceBetween: 0,
            loop: true,
            navigation: {
                nextEl: '.menu-button-next',
                prevEl: '.menu-button-prev',
            },
            slideToClickedSlide: true
        });

        const contentSwiper = new Swiper('.content-swiper', {
            direction: 'horizontal',
            slidesPerView: 1,
            spaceBetween: 0,
            loop: true
        });

        menuSwiper.on('click', function() {
            const clickedIndex = this.clickedIndex;
            if (clickedIndex !== undefined) {
                const realIdx = this.slides[clickedIndex].getAttribute('data-swiper-slide-index');
                contentSwiper.slideToLoop(parseInt(realIdx));
            }
        });

        menuSwiper.on('slideChange', function() {
            contentSwiper.slideToLoop(this.realIndex);
        });

        contentSwiper.on('slideChange', function() {
            menuSwiper.slideToLoop(this.realIndex);
        });
    }

    const sliderSpes = document.querySelector('.spes_block');

    if(sliderSpes){
        const tabLinks = document.querySelectorAll('.spes_tab_title ul li a');
        const tabBodies = document.querySelectorAll('.tab_body');
        
        tabBodies.forEach(tab => tab.classList.remove('active'));
        tabBodies[0].classList.add('active');
        
        tabLinks.forEach((link, index) => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                tabLinks.forEach(item => item.parentElement.classList.remove('active'));
                tabBodies.forEach(body => body.classList.remove('active'));
                
                this.parentElement.classList.add('active');
                tabBodies[index].classList.add('active');
                
                initSwiper(index);
            });
        });
        
        function initSwiper(tabIndex) {
            const activeTab = tabBodies[tabIndex];
            const swiperContainer = activeTab.querySelector('.swiper_product');
            
            if (swiperContainer && !swiperContainer.swiper) {
                new Swiper(swiperContainer, {
                    slidesPerView: 1,
                    spaceBetween: 20,
                    navigation: {
                        nextEl: swiperContainer.closest('.tab_body').querySelector('.swiper-button-next'),
                        prevEl: swiperContainer.closest('.tab_body').querySelector('.swiper-button-prev'),
                    },
                    scrollbar: {
                        el: swiperContainer.closest('.tab_body').querySelector('.swiper-scrollbar'),
                        draggable: true,
                        dragSize: 132, 
                    },
                    breakpoints: {
                        640: {
                            slidesPerView: 2,
                            spaceBetween: 20,
                        },
                        768: {
                            slidesPerView: 3,
                            spaceBetween: 20,
                        },
                        1024: {
                            slidesPerView: 4,
                            spaceBetween: 20,
                        },
                        1280: {
                            slidesPerView: 5,
                            spaceBetween: 20,
                        }
                    }
                });
            }
        }
        
        initSwiper(0);
    }
});